package Main;

import Model.Model;
import Service.Service;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Service manager = new Service();

        // Tambah data default supaya tidak kosong
        manager.seedDefault();

        while (true) {
            System.out.println("\n=== Sistem Manajemen Jadwal Service Kendaraan ===");
            System.out.println("1. Lihat Semua Jadwal");
            System.out.println("2. Tambah Jadwal");
            System.out.println("3. Ubah Jadwal (berdasarkan ID)");
            System.out.println("4. Hapus Jadwal (berdasarkan ID)");
            System.out.println("5. Cari berdasarkan Nama Pemilik");
            System.out.println("6. Keluar");
            System.out.print("Pilih menu: ");

            String pilihanStr = sc.nextLine();
            int pilihan;
            try {
                pilihan = Integer.parseInt(pilihanStr);
            } catch (NumberFormatException e) {
                System.out.println("Input tidak valid. Masukkan angka menu.");
                continue;
            }

            switch (pilihan) {
                case 1:
                    ArrayList<Model> all = manager.getAll();
                    if (all.isEmpty()) {
                        System.out.println("Belum ada data service.");
                    } else {
                        System.out.println("\n=== Daftar Jadwal Service ===");
                        for (Model s : all) {
                            System.out.println(s.toString());
                        }
                    }
                    break;

                case 2:
                    System.out.print("Nama Pemilik: ");
                    String owner = sc.nextLine();
                    System.out.print("Jenis Kendaraan: ");
                    String vehicle = sc.nextLine();
                    System.out.print("Tanggal Service (YYYY-MM-DD): ");
                    String date = sc.nextLine();
                    System.out.print("Jenis Service: ");
                    String serviceType = sc.nextLine();

                    if (owner.isEmpty() || vehicle.isEmpty() || date.isEmpty() || serviceType.isEmpty()) {
                        System.out.println("Semua field harus diisi.");
                    } else {
                        manager.add(new Model(owner, vehicle, date, serviceType));
                        System.out.println("Jadwal berhasil ditambahkan.");
                    }
                    break;

                case 3:
                    System.out.print("Masukkan ID yang ingin diubah: ");
                    int idU = Integer.parseInt(sc.nextLine());
                    manager.updateData(sc, idU);
                    break;

                case 4:
                    System.out.print("Masukkan ID yang ingin dihapus: ");
                    int idD = Integer.parseInt(sc.nextLine());
                    boolean removed = manager.delete(idD);
                    if (removed) System.out.println("Data berhasil dihapus.");
                    else System.out.println("Data tidak ditemukan.");
                    break;

                case 5:
                    System.out.print("Masukkan keyword nama pemilik: ");
                    String kw = sc.nextLine();
                    ArrayList<Model> hasil = manager.searchByOwner(kw);
                    if (hasil.isEmpty()) {
                        System.out.println("Tidak ditemukan data.");
                    } else {
                        for (Model s : hasil) System.out.println(s.toString());
                    }
                    break;

                case 6:
                    System.out.println("Terima kasih.");
                    sc.close();
                    return;

                default:
                    System.out.println("Pilihan tidak valid.");
            }
        }
    }
}
