package Service;

import Model.Model;
import java.util.ArrayList;
import java.util.Scanner;

public class Service {
    private ArrayList<Model> daftarService = new ArrayList<>();

    public void seedDefault() {
        daftarService.add(new Model("Budi", "Motor", "2025-09-20", "Service Ringan"));
        daftarService.add(new Model("Ani", "Mobil", "2025-09-21", "Ganti Oli"));
    }

    public void add(Model s) {
        daftarService.add(s);
    }

    public ArrayList<Model> getAll() {
        return daftarService;
    }

    public boolean delete(int id) {
        return daftarService.removeIf(s -> s.getId() == id);
    }

    public Model findById(int id) {
        for (Model s : daftarService) {
            if (s.getId() == id) return s;
        }
        return null;
    }

    public boolean update(int id, String owner, String vehicle, String date, String serviceType) {
        Model s = findById(id);
        if (s != null) {
            if (!owner.isEmpty()) s.setOwner(owner);
            if (!vehicle.isEmpty()) s.setVehicleType(vehicle);
            if (!date.isEmpty()) s.setDate(date);
            if (!serviceType.isEmpty()) s.setServiceType(serviceType);
            return true;
        }
        return false;
    }

    public void updateData(Scanner sc, int id) {
        Model s = findById(id);
        if (s == null) {
            System.out.println("Data tidak ditemukan.");
            return;
        }
        System.out.print("Nama Pemilik baru (" + s.getOwner() + "): ");
        String newOwner = sc.nextLine();
        System.out.print("Jenis Kendaraan baru (" + s.getVehicleType() + "): ");
        String newVehicle = sc.nextLine();
        System.out.print("Tanggal Service baru (" + s.getDate() + "): ");
        String newDate = sc.nextLine();
        System.out.print("Jenis Service baru (" + s.getServiceType() + "): ");
        String newService = sc.nextLine();

        update(id, newOwner, newVehicle, newDate, newService);
        System.out.println("Data berhasil diubah.");
    }

    public ArrayList<Model> searchByOwner(String keyword) {
        ArrayList<Model> hasil = new ArrayList<>();
        for (Model s : daftarService) {
            if (s.getOwner().toLowerCase().contains(keyword.toLowerCase())) {
                hasil.add(s);
            }
        }
        return hasil;
    }
}
