package Model;

public class Model {
    private static int counter = 1;
    private int id;
    private String owner;
    private String vehicleType;
    private String date;
    private String serviceType;

    public Model(String owner, String vehicleType, String date, String serviceType) {
        this.id = counter++;
        this.owner = owner;
        this.vehicleType = vehicleType;
        this.date = date;
        this.serviceType = serviceType;
    }

    public int getId() { return id; }
    public String getOwner() { return owner; }
    public String getVehicleType() { return vehicleType; }
    public String getDate() { return date; }
    public String getServiceType() { return serviceType; }

    public void setOwner(String owner) { this.owner = owner; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }
    public void setDate(String date) { this.date = date; }
    public void setServiceType(String serviceType) { this.serviceType = serviceType; }

    @Override
    public String toString() {
        return id + ". " + owner + " | " + vehicleType + " | " + date + " | " + serviceType;
    }
}
